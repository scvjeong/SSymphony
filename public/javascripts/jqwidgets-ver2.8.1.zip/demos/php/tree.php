﻿<?php
	echo $_POST["tree"];
?>