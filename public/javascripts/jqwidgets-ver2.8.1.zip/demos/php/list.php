﻿<?php
	echo $_POST["list"];
?>